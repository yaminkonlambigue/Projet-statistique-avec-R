---
title: "TP3 : "
author: "KONLAMBIGUE L. Youdan-yamin"
date: "2024-05-03"
output: 
  html_document:
    toc: true
    toc_depth: 3
    toc_float: true
    number_sections: true
    code_folding: show
    keep_md: true
---





```r
library(tidyverse) # general wrangling
library(readxl) # manipuler les fichiers excel
library(gtsummary) # to demonstrate automatic use of variable labels in 
library(ggstats)
library(ggplot2)
library(plotly)
```


```r
rm(list = ls())
```


# Importation des données 


```r
gni <- read.csv("../data/annual-growth-in-gni-per-capita.csv") 
gender <- read.csv("../data/gender-inequality-index.csv") 
population <- read.csv("../data/population-growth-annual.csv") 
```

# Graphique 1
## constitution de la base nécessaire 

```r
wester <- c("Benin", "Burkina Faso", "Cabo Verde","Gambia", "Ghana", "Guinea", "Guinea-Bissau","Côte d’Ivoire", "Liberia", "Mali","Mauritania", "Niger", "Nigeria", "Senegal","Sierra Leone","Togo")

data_1_Nig <- gni %>% filter(Region.Name=="Niger") %>%
             select("Start.Year", "Value") %>% 
              rename ("Niger" = "Value") 

data_1_west <- gni %>% filter(Region.Name %in% wester) %>%
             group_by(Start.Year) %>%
             summarize(Western_africa = mean(Value))

data_1_world <- gni %>% group_by(Start.Year) %>%
                    summarize(World = mean(Value))

data_1_ <- full_join(data_1_world, data_1_west, by = "Start.Year") %>%
          full_join(data_1_Nig , by = "Start.Year")

data_1 <- tidyr::pivot_longer(data_1_, cols = -Start.Year, names_to = "Region", values_to = "Value")
```

## Graphique : 

```r
col1=c(rgb(0,0,1), rgb(0.45,0.45,0.45), rgb(0.65,0.65,0.65))
data_1 %>%
  ggplot(aes(Start.Year, Value,  color = Region )) +
  geom_line(size = 0.5, show.legend=NULL)+
    geom_point(size = 1.5)+
        theme_minimal()+
          scale_y_continuous(limits = c(-20, 10)) + 
          scale_x_continuous(breaks=c(1970,1980,1990,2000,2010,2020),
                             labels = c("1970","1980","1990","2000",
                                        "2010","2020"))+ 
          scale_color_manual(values = col1)+ # palette de couleurs
          ggtitle(expression(italic("Figure : Income growth and distribution (Gini Index)"))) +
          labs(colour = "", x="", y="",caption = "Source: World Bank")+ # source caption
              
               theme(
                plot.title = element_text(color = rgb(0,0,1), 
                                          face = "italic", 
                                          size=11, vjust = 8, hjust = -0.17),
                plot.caption = element_text(face = "italic",  hjust = -0.095),
                 #lignes (pleines) principales verticales 
                panel.grid.major.x = element_line(colour = "grey",
                                                  size = 0.1, 
                                                  linetype = "solid"),
                # Supprime les lignes de grille secondaires
                panel.grid.minor.x = element_blank(), 
                #lignes (pointillées) principale horizontales 
                panel.grid.major.y = element_line(colour = "grey", 
                                                  size = 0.1, 
                                                  linetype = "dashed"), 
                # Supprime les lignes de grille secondaires
                panel.grid.minor.y = element_blank(),
               legend.position = c(0.12, 1.05), # position de la legende
               legend.direction="horizontal",# direction de la legende
               #définir les marges du cadran du graphique
               plot.margin = margin(1, 1, 1, 1, "cm") 
              )+
              #Ajuster la taille des points dans la légende
              guides(color = guide_legend(override.aes = list(size = 3))) 
```

![](script_TP3_files/figure-html/unnamed-chunk-2-1.png)<!-- -->

# Graphique 2
## constitution de la base nécessaire 

```r
wester <- c("Benin", "Burkina Faso", "Cabo Verde","Gambia", "Ghana", "Guinea", "Guinea-Bissau","Côte d’Ivoire", "Liberia", "Mali","Mauritania", "Niger", "Nigeria", "Senegal","Sierra Leone","Togo")

data_2_Nig <- population %>% filter(Region.Name=="Niger") %>%
             select("Start.Year", "Value") %>% 
              rename ("Niger" = "Value") 

data_2_west <- population %>% filter(Region.Name %in% wester) %>%
             group_by(Start.Year) %>%
             summarize(Western_africa = mean(Value))

data_2_world <- population %>% group_by(Start.Year) %>%
                    summarize(World = mean(Value))

data_2_ <- full_join(data_2_world, data_2_west, by = "Start.Year") %>%
          full_join(data_2_Nig , by = "Start.Year")

data_2 <- tidyr::pivot_longer(data_2_, cols = -Start.Year, names_to = "Region", values_to = "Value")
```

## Graphique : 

```r
col1=c(rgb(0,0,0.9), rgb(0.45,0.45,0.45), rgb(0.65,0.65,0.65))
data_2 %>%
  ggplot(aes(Start.Year, Value,  color = Region )) +
  geom_line(size = 0.5, show.legend=NULL)+
    geom_point(size = 1.5)+
        theme_minimal()+
          scale_y_continuous(limits = c(0, 4)) + 
          scale_x_continuous(breaks=c(1960, 1970,1980,1990,2000,2010,2020),
                             labels = c("1960","1970","1980","1990","2000",
                                        "2010","2020"))+ 
          scale_color_manual(values = col1)+ # palette de couleurs
          ggtitle(expression(italic("Figure: Annual population growth (%)"))) +
          labs(colour = "", x="", y="",caption = "Source: World Bank")+ # source caption
              
               theme(
                plot.title = element_text(color = rgb(0,0,1), 
                                          face = "italic", 
                                          size=11, vjust = 8, hjust = -0.17),
                plot.caption = element_text(face = "italic",  hjust = -0.095),
                 #lignes (pleines) principales verticales 
                panel.grid.major.x = element_line(colour = "grey",
                                                  size = 0.1, 
                                                  linetype = "solid"),
                # Supprime les lignes de grille secondaires
                panel.grid.minor.x = element_blank(), 
                #lignes (pointillées) principale horizontales 
                panel.grid.major.y = element_line(colour = "grey", 
                                                  size = 0.1, 
                                                  linetype = "dashed"), 
                # Supprime les lignes de grille secondaires
                panel.grid.minor.y = element_blank(),
               legend.position = c(0.12, 1.05), # position de la legende
               legend.direction="horizontal",# direction de la legende
               #définir les marges du cadran du graphique
               plot.margin = margin(1, 1, 1, 1, "cm") 
              )+
              #Ajuster la taille des points dans la légende
              guides(color = guide_legend(override.aes = list(size = 3))) 
```

![](script_TP3_files/figure-html/unnamed-chunk-4-1.png)<!-- -->

# Graphique 3
## constitution de la base nécessaire 

```r
wester <- c("Benin", "Burkina Faso", "Cabo Verde","Gambia", "Ghana", "Guinea", "Guinea-Bissau","Côte d’Ivoire", "Liberia", "Mali","Mauritania", "Niger", "Nigeria", "Senegal","Sierra Leone","Togo")

data_3_Nig <- gender %>% filter(Region.Name=="Niger") %>%
             select("Start.Year", "Value") %>% 
              rename ("Niger" = "Value") 

data_3_west <- gender %>% filter(Region.Name %in% wester) %>%
             group_by(Start.Year) %>%
             summarize(Western_africa = mean(Value))

data_3_world <- gender %>% group_by(Start.Year) %>%
                    summarize(World = mean(Value))

data_3_ <- full_join(data_3_world, data_3_west, by = "Start.Year") %>%
          full_join(data_3_Nig , by = "Start.Year")

data_3 <- tidyr::pivot_longer(data_3_, cols = -Start.Year, names_to = "Region", values_to = "Value")
```

## Graphique : 

```r
col1=c(rgb(0,0,0.9), rgb(0.45,0.45,0.45), rgb(0.65,0.65,0.65))
 graph <- data_3 %>%
  ggplot(aes(Start.Year, Value,  color = Region )) +
   geom_point(size = 1.5,aes(text=paste(Region,":", round(Value,1))))+
  geom_line(size = 0.5)+
    
        theme_minimal()+
          scale_y_continuous(limits = c(0.1, 0.8)) + 
          scale_x_continuous(breaks=c(1990,1995,2000,2005,2010,2015,2020),
                             labels = c("1990","1995","2000","2005","2010","2015","2020"))+ 
          scale_color_manual(values = col1)+ # palette de couleurs
          scale_fill_manual(values =  col1)+
          ggtitle("Figure : Gender inequality index") +
          labs(colour = "", x="", y="",fill = "") + # source caption
              
               theme(
                plot.title = element_text(color = rgb(0,0,1), 
                                          face = "italic", 
                                          size=11),
         
               #définir les marges du cadran du graphique
               plot.margin = margin(1, 1, 1, 1, "cm") 
              )+
              #Ajuster la taille des points dans la légende
              guides(color = guide_legend(override.aes = list(size = 3))) 

 
ggplotly(graph, tooltip="text") %>%
  plotly::layout(title = list(
  # Définir le titre du graphique avec une police bleue, italique et une taille
                font = list(color = rgb(0,0,1), face = "italic", size = 12)),
    
                legend=list(title = NULL, # Supprimer le titre de la légende
                    # Positionner la légende à l'extrémité gauche du graphique
                             x = 0,   
                    # Positionner la légende en haut du graphique
                             y = 1.1,  
                    # Définir l'orientation horizontale de la légende
                             orientation = 'h' ), 
                    # définition de la source
                annotations = list(
                  x = 0.1,  # Position x de la source
                  y = -0.15,  # Position y de la source
                  text = "Source : UNDP",  # Texte de la source
                  showarrow = F,  # Supprime la flèche de la source
                  xref = 'paper',  # Référence de la position x 
                  yref = 'paper',  # Référence de la position y 
                  xanchor = 'right',  # Positionner la source  à droite sur X
                  yanchor = 'auto',  # Positionner la source  à droite sur Y
                  # Personnaliser la police de la source
                  font = list(size = 11, color = "black"))
                 )
```

```{=html}
<div class="plotly html-widget html-fill-item" id="htmlwidget-e5731034f9292c58dd6f" style="width:672px;height:480px;"></div>
<script type="application/json" data-for="htmlwidget-e5731034f9292c58dd6f">{"x":{"data":[{"x":[1990,1991,1992,1993,1994,1995,1996,1997,1998,1999,2000,2001,2002,2003,2004,2005,2006,2007,2008,2009,2010,2011,2012,2013,2014,2015,2016,2017,2018,2019,2020,2021],"y":[0.79600000000000004,0.79500000000000004,0.79500000000000004,0.79500000000000004,0.79500000000000004,0.79700000000000004,0.79600000000000004,0.79500000000000004,0.79400000000000004,0.79300000000000004,0.79200000000000004,0.79000000000000004,0.78800000000000003,0.78700000000000003,0.69899999999999995,0.69699999999999995,0.69499999999999995,0.69299999999999995,0.68999999999999995,0.69699999999999995,0.69399999999999995,0.67400000000000004,0.66900000000000004,0.66400000000000003,0.66000000000000003,0.65600000000000003,0.64800000000000002,0.63700000000000001,0.63500000000000001,0.63200000000000001,0.63100000000000001,0.61099999999999999],"text":["Niger : 0.8","Niger : 0.8","Niger : 0.8","Niger : 0.8","Niger : 0.8","Niger : 0.8","Niger : 0.8","Niger : 0.8","Niger : 0.8","Niger : 0.8","Niger : 0.8","Niger : 0.8","Niger : 0.8","Niger : 0.8","Niger : 0.7","Niger : 0.7","Niger : 0.7","Niger : 0.7","Niger : 0.7","Niger : 0.7","Niger : 0.7","Niger : 0.7","Niger : 0.7","Niger : 0.7","Niger : 0.7","Niger : 0.7","Niger : 0.6","Niger : 0.6","Niger : 0.6","Niger : 0.6","Niger : 0.6","Niger : 0.6"],"type":"scatter","mode":"markers","marker":{"autocolorscale":false,"color":"rgba(0,0,230,1)","opacity":1,"size":5.6692913385826778,"symbol":"circle","line":{"width":1.8897637795275593,"color":"rgba(0,0,230,1)"}},"hoveron":"points","name":"(Niger,1)","legendgroup":"(Niger,1)","showlegend":true,"xaxis":"x","yaxis":"y","hoverinfo":"text","frame":null},{"x":[1990,1991,1992,1993,1994,1995,1996,1997,1998,1999,2000,2001,2002,2003,2004,2005,2006,2007,2008,2009,2010,2011,2012,2013,2014,2015,2016,2017,2018,2019,2020,2021],"y":[0.72030000000000005,0.71850000000000003,0.71720000000000006,0.71609999999999996,0.71450000000000002,0.71289999999999998,0.71150000000000002,0.71020000000000005,0.70440000000000003,0.69999999999999996,0.69169230769230772,0.68830769230769229,0.68300000000000005,0.67314285714285715,0.66642857142857148,0.65973333333333339,0.6512,0.64626666666666666,0.64573333333333338,0.64473333333333338,0.64353333333333329,0.64213333333333333,0.63660000000000005,0.6313333333333333,0.62706666666666666,0.61231250000000004,0.60881249999999998,0.60312500000000002,0.60143749999999996,0.59887500000000005,0.59837499999999999,0.59375],"text":["Western_africa : 0.7","Western_africa : 0.7","Western_africa : 0.7","Western_africa : 0.7","Western_africa : 0.7","Western_africa : 0.7","Western_africa : 0.7","Western_africa : 0.7","Western_africa : 0.7","Western_africa : 0.7","Western_africa : 0.7","Western_africa : 0.7","Western_africa : 0.7","Western_africa : 0.7","Western_africa : 0.7","Western_africa : 0.7","Western_africa : 0.7","Western_africa : 0.6","Western_africa : 0.6","Western_africa : 0.6","Western_africa : 0.6","Western_africa : 0.6","Western_africa : 0.6","Western_africa : 0.6","Western_africa : 0.6","Western_africa : 0.6","Western_africa : 0.6","Western_africa : 0.6","Western_africa : 0.6","Western_africa : 0.6","Western_africa : 0.6","Western_africa : 0.6"],"type":"scatter","mode":"markers","marker":{"autocolorscale":false,"color":"rgba(115,115,115,1)","opacity":1,"size":5.6692913385826778,"symbol":"circle","line":{"width":1.8897637795275593,"color":"rgba(115,115,115,1)"}},"hoveron":"points","name":"(Western_africa,1)","legendgroup":"(Western_africa,1)","showlegend":true,"xaxis":"x","yaxis":"y","hoverinfo":"text","frame":null},{"x":[1990,1991,1992,1993,1994,1995,1996,1997,1998,1999,2000,2001,2002,2003,2004,2005,2006,2007,2008,2009,2010,2011,2012,2013,2014,2015,2016,2017,2018,2019,2020,2021],"y":[0.48757812499999997,0.48507812499999997,0.48176562499999998,0.47848437500000002,0.47474218750000002,0.4706153846153846,0.4656153846153846,0.4605153846153846,0.45937499999999998,0.45480851063829786,0.44871527777777775,0.44426845637583895,0.43871333333333334,0.43379084967320264,0.42841025641025643,0.42323899371069185,0.41443827160493829,0.40620858895705519,0.4039325153374233,0.39999386503067486,0.39871515151515152,0.39391017964071856,0.38750299401197608,0.37971856287425149,0.37722754491017962,0.37178571428571427,0.3652130177514793,0.35588823529411767,0.35178235294117649,0.34691764705882355,0.34415882352941179,0.34437647058823528],"text":["World : 0.5","World : 0.5","World : 0.5","World : 0.5","World : 0.5","World : 0.5","World : 0.5","World : 0.5","World : 0.5","World : 0.5","World : 0.4","World : 0.4","World : 0.4","World : 0.4","World : 0.4","World : 0.4","World : 0.4","World : 0.4","World : 0.4","World : 0.4","World : 0.4","World : 0.4","World : 0.4","World : 0.4","World : 0.4","World : 0.4","World : 0.4","World : 0.4","World : 0.4","World : 0.3","World : 0.3","World : 0.3"],"type":"scatter","mode":"markers","marker":{"autocolorscale":false,"color":"rgba(166,166,166,1)","opacity":1,"size":5.6692913385826778,"symbol":"circle","line":{"width":1.8897637795275593,"color":"rgba(166,166,166,1)"}},"hoveron":"points","name":"(World,1)","legendgroup":"(World,1)","showlegend":true,"xaxis":"x","yaxis":"y","hoverinfo":"text","frame":null},{"x":[1990,1991,1992,1993,1994,1995,1996,1997,1998,1999,2000,2001,2002,2003,2004,2005,2006,2007,2008,2009,2010,2011,2012,2013,2014,2015,2016,2017,2018,2019,2020,2021],"y":[0.79600000000000004,0.79500000000000004,0.79500000000000004,0.79500000000000004,0.79500000000000004,0.79700000000000004,0.79600000000000004,0.79500000000000004,0.79400000000000004,0.79300000000000004,0.79200000000000004,0.79000000000000004,0.78800000000000003,0.78700000000000003,0.69899999999999995,0.69699999999999995,0.69499999999999995,0.69299999999999995,0.68999999999999995,0.69699999999999995,0.69399999999999995,0.67400000000000004,0.66900000000000004,0.66400000000000003,0.66000000000000003,0.65600000000000003,0.64800000000000002,0.63700000000000001,0.63500000000000001,0.63200000000000001,0.63100000000000001,0.61099999999999999],"text":"","type":"scatter","mode":"lines","line":{"width":1.8897637795275593,"color":"rgba(0,0,230,1)","dash":"solid"},"hoveron":"points","name":"(Niger,1)","legendgroup":"(Niger,1)","showlegend":false,"xaxis":"x","yaxis":"y","hoverinfo":"text","frame":null},{"x":[1990,1991,1992,1993,1994,1995,1996,1997,1998,1999,2000,2001,2002,2003,2004,2005,2006,2007,2008,2009,2010,2011,2012,2013,2014,2015,2016,2017,2018,2019,2020,2021],"y":[0.72030000000000005,0.71850000000000003,0.71720000000000006,0.71609999999999996,0.71450000000000002,0.71289999999999998,0.71150000000000002,0.71020000000000005,0.70440000000000003,0.69999999999999996,0.69169230769230772,0.68830769230769229,0.68300000000000005,0.67314285714285715,0.66642857142857148,0.65973333333333339,0.6512,0.64626666666666666,0.64573333333333338,0.64473333333333338,0.64353333333333329,0.64213333333333333,0.63660000000000005,0.6313333333333333,0.62706666666666666,0.61231250000000004,0.60881249999999998,0.60312500000000002,0.60143749999999996,0.59887500000000005,0.59837499999999999,0.59375],"text":"","type":"scatter","mode":"lines","line":{"width":1.8897637795275593,"color":"rgba(115,115,115,1)","dash":"solid"},"hoveron":"points","name":"(Western_africa,1)","legendgroup":"(Western_africa,1)","showlegend":false,"xaxis":"x","yaxis":"y","hoverinfo":"text","frame":null},{"x":[1990,1991,1992,1993,1994,1995,1996,1997,1998,1999,2000,2001,2002,2003,2004,2005,2006,2007,2008,2009,2010,2011,2012,2013,2014,2015,2016,2017,2018,2019,2020,2021],"y":[0.48757812499999997,0.48507812499999997,0.48176562499999998,0.47848437500000002,0.47474218750000002,0.4706153846153846,0.4656153846153846,0.4605153846153846,0.45937499999999998,0.45480851063829786,0.44871527777777775,0.44426845637583895,0.43871333333333334,0.43379084967320264,0.42841025641025643,0.42323899371069185,0.41443827160493829,0.40620858895705519,0.4039325153374233,0.39999386503067486,0.39871515151515152,0.39391017964071856,0.38750299401197608,0.37971856287425149,0.37722754491017962,0.37178571428571427,0.3652130177514793,0.35588823529411767,0.35178235294117649,0.34691764705882355,0.34415882352941179,0.34437647058823528],"text":"","type":"scatter","mode":"lines","line":{"width":1.8897637795275593,"color":"rgba(166,166,166,1)","dash":"solid"},"hoveron":"points","name":"(World,1)","legendgroup":"(World,1)","showlegend":false,"xaxis":"x","yaxis":"y","hoverinfo":"text","frame":null}],"layout":{"margin":{"t":83.525257972890358,"r":37.795275590551171,"b":68.255851580196293,"l":58.982490202423321},"font":{"color":"rgba(0,0,0,1)","family":"","size":14.611872146118724},"title":{"text":"<i> Figure : Gender inequality index <\/i>","font":{"color":"#0000FF","family":"","size":12,"face":"italic"},"x":0,"xref":"paper"},"xaxis":{"domain":[0,1],"automargin":true,"type":"linear","autorange":false,"range":[1988.45,2022.55],"tickmode":"array","ticktext":["1990","1995","2000","2005","2010","2015","2020"],"tickvals":[1990,1995,2000,2005,2010,2015,2020],"categoryorder":"array","categoryarray":["1990","1995","2000","2005","2010","2015","2020"],"nticks":null,"ticks":"","tickcolor":null,"ticklen":3.6529680365296811,"tickwidth":0,"showticklabels":true,"tickfont":{"color":"rgba(77,77,77,1)","family":"","size":11.68949771689498},"tickangle":-0,"showline":false,"linecolor":null,"linewidth":0,"showgrid":true,"gridcolor":"rgba(235,235,235,1)","gridwidth":0.66417600664176002,"zeroline":false,"anchor":"y","title":{"text":"","font":{"color":"rgba(0,0,0,1)","family":"","size":14.611872146118724}},"hoverformat":".2f"},"yaxis":{"domain":[0,1],"automargin":true,"type":"linear","autorange":false,"range":[0.065000000000000002,0.83500000000000008],"tickmode":"array","ticktext":["0.2","0.4","0.6","0.8"],"tickvals":[0.20000000000000001,0.40000000000000002,0.60000000000000009,0.80000000000000004],"categoryorder":"array","categoryarray":["0.2","0.4","0.6","0.8"],"nticks":null,"ticks":"","tickcolor":null,"ticklen":3.6529680365296811,"tickwidth":0,"showticklabels":true,"tickfont":{"color":"rgba(77,77,77,1)","family":"","size":11.68949771689498},"tickangle":-0,"showline":false,"linecolor":null,"linewidth":0,"showgrid":true,"gridcolor":"rgba(235,235,235,1)","gridwidth":0.66417600664176002,"zeroline":false,"anchor":"x","title":{"text":"","font":{"color":"rgba(0,0,0,1)","family":"","size":14.611872146118724}},"hoverformat":".2f"},"shapes":[{"type":"rect","fillcolor":null,"line":{"color":null,"width":0,"linetype":[]},"yref":"paper","xref":"paper","x0":0,"x1":1,"y0":0,"y1":1}],"showlegend":true,"legend":{"bgcolor":null,"bordercolor":null,"borderwidth":0,"font":{"color":"rgba(0,0,0,1)","family":"","size":11.68949771689498},"title":{"text":"","font":{"color":"rgba(0,0,0,1)","family":"","size":14.611872146118724}},"x":0,"y":1.1000000000000001,"orientation":"h"},"hovermode":"closest","barmode":"relative","annotations":[{"x":0.10000000000000001,"y":-0.14999999999999999,"text":"Source : UNDP","showarrow":false,"xref":"paper","yref":"paper","xanchor":"right","yanchor":"auto","font":{"size":11,"color":"black"}},{"x":0.10000000000000001,"y":-0.14999999999999999,"text":"Source : UNDP","showarrow":false,"xref":"paper","yref":"paper","xanchor":"right","yanchor":"auto","font":{"size":11,"color":"black"}}]},"config":{"doubleClick":"reset","modeBarButtonsToAdd":["hoverclosest","hovercompare"],"showSendToCloud":false},"source":"A","attrs":{"3f7845bc1493":{"x":{},"y":{},"colour":{},"text":{},"type":"scatter"},"3f78ee22574":{"x":{},"y":{},"colour":{}}},"cur_data":"3f7845bc1493","visdat":{"3f7845bc1493":["function (y) ","x"],"3f78ee22574":["function (y) ","x"]},"highlight":{"on":"plotly_click","persistent":false,"dynamic":false,"selectize":false,"opacityDim":0.20000000000000001,"selected":{"opacity":1},"debounce":0},"shinyEvents":["plotly_hover","plotly_click","plotly_selected","plotly_relayout","plotly_brushed","plotly_brushing","plotly_clickannotation","plotly_doubleclick","plotly_deselect","plotly_afterplot","plotly_sunburstclick"],"base_url":"https://plot.ly"},"evals":[],"jsHooks":[]}</script>
```

